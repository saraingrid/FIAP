
import {useState} from "react";
import {useRouter} from "next/router";

const LoginPage : React.FC = () =>{ //ver o que é react.fc
    const router = useRouter();
    const [username, setUsername] = useState("")
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");

    const handleLogin = () =>{ 
        if(username === 'admin' && password === 'admin'){
            //a diferença entre local Storage e Section Storage é que 
            //Local storage permanece até que apaguemos o loggedIn já o Section Storage desloga
            //assim que o usuario fecha o navegador
            
            localStorage.setItem('isLoggedIn', 'true') 
            router.push('/dashboard')
        }else{
                setError("Usuário e/ou senha incorretos!")
        }
    }

    return (
        <>
        <form>
            <label>Usuário: 
                <input type="text" value={ username } placeholder="Username" onChange=
                { (e) => setUsername(e.target.value)}/> 
            </label>
            < br />
            <label> Senha:
                <input type="password" value = { password } placeholder="Password"
                onChange= {(e) => setPassword(e.target.value)} /> 
            </label>
            <br />
                {error && <span>{error}</span>}
            <br />
            <button type="button" onClick={ handleLogin }>Login</button>
        </form>
        </>
    )
}

export default LoginPage;