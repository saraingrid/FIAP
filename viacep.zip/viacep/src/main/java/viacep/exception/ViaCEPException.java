package viacep.exception;

public class ViaCEPException extends Exception{
	
	//polimorfismo = sobrecarga de método

	public ViaCEPException(String mensagem) {
		super(mensagem);
	}
	
	public ViaCEPException(String mensagem, Throwable causa) {
		super(mensagem, causa);
	}
}
